window.onkeydown = function (e) {
    key[e.keyCode] = true;
    this.checkKeys();

};

window.onkeyup = function (e) {
    key[e.keyCode] = false;
    this.checkKeys();
};

var playerAUsername = "Player A";
var playerBUsername = "Player B";

var playerAPosX = 0;
var playerAPosY = 0;
var playerBPosX = 475;
var playerBPosY = 475;

var playerAHealth = 50;
var playerBHealth = 50;

var playerAMoveDistance = 25;
var playerBMoveDistance = 25;

var playerADamage = 1;
var playerBDamage = 1;

var scoreA = 0;
var scoreB = 0;

var resetMode = false;

var key = [];

var tagBody = '(?:[^"\'>]|"[^"]*"|\'[^\']*\')*';
var tagOrComment = new RegExp(
    '<(?:'
    + '!--(?:(?:-*[^->])*--+|-?)'
    + '|script\\b' + tagBody + '>[\\s\\S]*?</script\\s*'
    + '|style\\b' + tagBody + '>[\\s\\S]*?</style\\s*'
    + '|/?[a-z]'
    + tagBody
    + ')>',
    'gi');

function checkKeys() {
    if (key[87]) {
        this.moveTileA(0, -playerAMoveDistance);
    }
    if (key[65]) {
        this.moveTileA(-playerAMoveDistance, 0);
    }
    if (key[83]) {
        this.moveTileA(0, playerAMoveDistance);
    }
    if (key[68]) {
        this.moveTileA(playerAMoveDistance, 0);
    }
    if (key[38]) {
        this.moveTileB(0, -playerBMoveDistance);
    }
    if (key[37]) {
        this.moveTileB(-playerBMoveDistance, 0);
    }
    if (key[40]) {
        this.moveTileB(0, playerBMoveDistance);
    }
    if (key[39]) {
        this.moveTileB(playerBMoveDistance, 0);
    }
}

function moveTileA(x, y) {
    var elem = document.getElementById("playerA");
    if (!resetMode) {
        if (this.isCollided(elem, document.getElementById("playerB"), x, y)) {
            playerBHealth -= playerADamage;
            document.getElementById("healthB").value = playerBHealth;
            if (playerBHealth <= 0) {
                this.win("A");
            }
            return;
        }
        y = playerAPosY + y > 475 ? 475 - playerAPosY : (playerAPosY + y < 0 ? 0 - playerAPosY : y);
        elem.style.top = playerAPosY + y + 'px';
        playerAPosY += y;
        x = playerAPosX + x > 475 ? 475 - playerAPosX : (playerAPosX + x < 0 ? 0 - playerAPosX : x);
        elem.style.left = playerAPosX + x + 'px';
        playerAPosX += x;
    }
}

function moveTileB(x, y) {
    var elem = document.getElementById("playerB");
    if (!resetMode) {
        if (this.isCollided(elem, document.getElementById("playerA"), x, y)) {
            playerAHealth -= playerBDamage;
            document.getElementById("healthA").value = playerAHealth;
            if (playerAHealth <= 0) {
                this.win("B");
            }
            return;
        }
        y = playerBPosY + y > 475 ? 475 - playerBPosY : (playerBPosY + y < 0 ? 0 - playerBPosY : y);
        elem.style.top = playerBPosY + y + 'px';
        playerBPosY += y;
        x = playerBPosX + x > 475 ? 475 - playerBPosX : (playerBPosX + x < 0 ? 0 - playerBPosX : x);
        elem.style.left = playerBPosX + x + 'px';
        playerBPosX += x;
    }
}

function usernameAUsernameInput(input) {
    input = this.removeTags(input);
    input = input.length > 16 ? input.substring(0, 16) : input;
    playerAUsername = input;
    document.getElementById("playerA").innerHTML = input;
    document.getElementById("healthAText").innerHTML = input + "'s Health";
    document.getElementById("scoreA").innerHTML = input + ": " + scoreA;
}

function usernameBUsernameInput(input) {
    input = this.removeTags(input);
    input = input.length > 16 ? input.substring(0, 16) : input;
    playerBUsername = input;
    document.getElementById("playerB").innerHTML = input;
    document.getElementById("healthBText").innerHTML = input + "'s Health";
    document.getElementById("scoreB").innerHTML = input + ": " + scoreB;
}

function usernameAColorInput(input) {
    document.getElementById("playerA").style.background = input;
}

function usernameBColorInput(input) {
    document.getElementById("playerB").style.background = input;
}


function win(player) {
    player === "A" ? scoreA++ : scoreB++;
    document.getElementById("score" + player).innerHTML = (player === "A" ? playerAUsername : playerBUsername) + ": " + (player === "A" ? scoreA : scoreB);
    alert((player === "A" ? playerAUsername : playerBUsername) + " wins! Press the Reset Game button to reset.");
    resetMode = true;
    document.getElementById("resetButton").style.cursor = "pointer";
}

function reset() {
    resetMode = false;
    document.getElementById("resetButton").style.cursor = "not-allowed";
    key = [];
    playerAHealth = 50;
    document.getElementById("healthA").value = playerAHealth;
    playerBHealth = 50;
    document.getElementById("healthB").value = playerBHealth;
    playerAPosY = 0;
    playerAPosX = 0;
    playerBPosY = 475;
    playerBPosX = 475;
    var playerA = document.getElementById("playerA");
    playerA.style.top = playerAPosY + 'px';
    playerA.style.left = playerAPosX + 'px';
    var playerB = document.getElementById("playerB");
    playerB.style.top = playerBPosY + 'px';
    playerB.style.left = playerBPosX + 'px';
    document.getElementById("healthA").innerHTML = playerAUsername + "'s Health: " + playerAHealth;
    document.getElementById("healthB").innerHTML = playerBUsername + "'s Health: " + playerBHealth;
    this.start();
}

function resetButton() {
    if (resetMode) {
        this.reset();
    }
}

function isCollided(a, b, x, y) {
    var aRect = a.getBoundingClientRect();
    var bRect = b.getBoundingClientRect();

    return !(
        ((aRect.top + aRect.height + y) < (bRect.top + 1)) ||
        (aRect.top + y > (bRect.top + bRect.height - 1)) ||
        ((aRect.left + aRect.width + x) < bRect.left + 1) ||
        (aRect.left + x > (bRect.left + bRect.width - 1))
    );
}

function removeTags(html) {
    var oldHtml;
    do {
        oldHtml = html;
        html = html.replace(tagOrComment, '');
    } while (html !== oldHtml);
    return html.replace(/</g, '&lt;');
}